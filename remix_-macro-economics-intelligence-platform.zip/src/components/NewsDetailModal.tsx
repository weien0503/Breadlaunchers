import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MessageSquare, TrendingUp, Clock, Download, Share2, Send, Sparkles, Mic, MicOff, Volume2, VolumeX, Loader2 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import ReactMarkdown from 'react-markdown';
import { analyzeNews, askMacroAgent } from '../services/geminiService';

interface NewsDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  news: {
    title: string;
    summary: string;
    source: string;
    time: string;
    category: string;
    image: string;
  } | null;
}

const NewsDetailModal = ({ isOpen, onClose, news }: NewsDetailModalProps) => {
  const [chatInput, setChatInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isReading, setIsReading] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiSummary, setAiSummary] = useState<string>('');
  const [impactData, setImpactData] = useState<any[]>([]);
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'ai', content: string }[]>([
    { role: 'ai', content: "Hello! I've analyzed this news. How can I help you understand its macro impact?" }
  ]);

  React.useEffect(() => {
    if (isOpen && news) {
      const performAnalysis = async () => {
        setIsAnalyzing(true);
        const result = await analyzeNews(news);
        setAiSummary(result.summary);
        setImpactData(result.impactData);
        setIsAnalyzing(false);
      };
      performAnalysis();
    } else {
      setAiSummary('');
      setImpactData([]);
      setChatHistory([{ role: 'ai', content: "Hello! I've analyzed this news. How can I help you understand its macro impact?" }]);
    }
  }, [isOpen, news]);

  if (!news) return null;

  const toggleReadAloud = () => {
    if (isReading) {
      window.speechSynthesis.cancel();
      setIsReading(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(`${news.title}. ${news.summary}`);
      utterance.onend = () => setIsReading(false);
      window.speechSynthesis.speak(utterance);
      setIsReading(true);
    }
  };

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }
    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setChatInput(transcript);
    };
    recognition.start();
  };

  const mockImpactData = [
    { name: 'T-1', value: 4000 },
    { name: 'T', value: 3000 },
    { name: 'T+1', value: 2000 },
    { name: 'T+2', value: 2780 },
    { name: 'T+3', value: 1890 },
    { name: 'T+4', value: 2390 },
    { name: 'T+5', value: 3490 },
  ];

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    const userMsg = chatInput;
    setChatHistory(prev => [...prev, { role: 'user', content: userMsg }]);
    setChatInput('');
    setIsAiLoading(true);
    
    // Call Gemini
    const history = chatHistory.map(m => ({
      role: m.role === 'ai' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));
    
    const prompt = `Context: This is about the news titled "${news.title}". 
    Summary: ${news.summary}
    
    User Question: ${userMsg}`;
    
    const response = await askMacroAgent(prompt, history);
    
    setChatHistory(prev => [...prev, { 
      role: 'ai', 
      content: response.text 
    }]);
    setIsAiLoading(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-6xl h-full max-h-[90vh] bg-[#0a0e14] border border-slate-800 rounded-3xl overflow-hidden flex flex-col md:flex-row"
          >
            {/* Left Column: Content & Charts */}
            <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-8 no-scrollbar">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-full uppercase tracking-widest">
                    {news.category}
                  </span>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1">
                    <Clock size={14} /> {news.time}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={toggleReadAloud}
                    className={`p-2 rounded-xl border transition-colors ${isReading ? 'bg-blue-600 border-blue-500 text-white' : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:text-white'}`}
                  >
                    {isReading ? <VolumeX size={18} /> : <Volume2 size={18} />}
                  </button>
                  <button className="p-2 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-colors">
                    <Download size={18} />
                  </button>
                  <button className="p-2 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-colors">
                    <Share2 size={18} />
                  </button>
                  <button onClick={onClose} className="p-2 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-colors">
                    <X size={18} />
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <h1 className="text-3xl md:text-4xl font-bold text-white leading-tight">{news.title}</h1>
                <p className="text-lg text-slate-400 leading-relaxed">{news.summary}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-[#141b26] p-6 rounded-2xl border border-slate-800/50">
                  <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <TrendingUp size={16} className="text-blue-500" /> Predicted Economic Impact
                  </h3>
                  <div className="h-48 w-full flex items-center justify-center">
                    {isAnalyzing ? (
                      <Loader2 className="animate-spin text-blue-500" size={32} />
                    ) : impactData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={impactData}>
                          <defs>
                            <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                          <XAxis dataKey="name" stroke="#4b5563" fontSize={10} tickLine={false} axisLine={false} />
                          <YAxis hide />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#141b26', border: '1px solid #1f2937', borderRadius: '8px' }}
                            itemStyle={{ color: '#fff', fontSize: '12px' }}
                          />
                          <Area type="monotone" dataKey="value" stroke="#3b82f6" fillOpacity={1} fill="url(#colorValue)" strokeWidth={2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    ) : (
                      <p className="text-xs text-slate-500">No impact data available</p>
                    )}
                  </div>
                </div>

                <div className="bg-[#141b26] p-6 rounded-2xl border border-slate-800/50">
                  <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <Clock size={16} className="text-amber-500" /> Event Timeline
                  </h3>
                  <div className="space-y-4">
                    {[
                      { time: 'T-2h', event: 'Initial Rumors', status: 'completed' },
                      { time: 'T-0', event: 'Official Announcement', status: 'current' },
                      { time: 'T+1h', event: 'Market Reaction Peak', status: 'upcoming' },
                      { time: 'T+4h', event: 'Central Bank Statement', status: 'upcoming' },
                    ].map((step, i) => (
                      <div key={i} className="flex items-center gap-4">
                        <span className="text-[10px] font-bold text-slate-500 w-8">{step.time}</span>
                        <div className={`size-2 rounded-full ${step.status === 'completed' ? 'bg-blue-500' : step.status === 'current' ? 'bg-amber-500 animate-pulse' : 'bg-slate-700'}`} />
                        <span className={`text-xs font-bold ${step.status === 'upcoming' ? 'text-slate-500' : 'text-white'}`}>{step.event}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-6 bg-blue-600/5 border border-blue-500/20 rounded-2xl">
                <h4 className="text-xs font-bold text-blue-500 uppercase mb-2 flex items-center gap-2">
                  <Sparkles size={14} /> AI Executive Summary
                </h4>
                {isAnalyzing ? (
                  <div className="flex items-center gap-2 text-slate-500 text-sm">
                    <Loader2 className="animate-spin" size={14} /> Analyzing macro impact...
                  </div>
                ) : (
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {aiSummary || "Unable to generate summary."}
                  </p>
                )}
              </div>
            </div>

            {/* Right Column: AI Chat */}
            <div className="w-full md:w-[400px] bg-[#141b26] border-l border-slate-800 flex flex-col">
              <div className="p-6 border-b border-slate-800 flex items-center gap-3">
                <div className="size-10 rounded-xl bg-blue-600/20 flex items-center justify-center text-blue-500">
                  <MessageSquare size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Macro AI Assistant</h3>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Context: {news.category}</p>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
                {chatHistory.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed ${
                      msg.role === 'user' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-slate-800/50 border border-slate-700 text-slate-300'
                    }`}>
                      <ReactMarkdown>{msg.content}</ReactMarkdown>
                    </div>
                  </div>
                ))}
                {isAiLoading && (
                  <div className="flex justify-start">
                    <div className="max-w-[85%] p-4 rounded-2xl bg-slate-800/50 border border-slate-700 text-slate-300 flex gap-1">
                      <div className="size-1.5 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                      <div className="size-1.5 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                      <div className="size-1.5 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6 border-t border-slate-800">
                <div className="relative flex gap-2">
                  <div className="relative flex-1">
                    <input 
                      type="text" 
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Ask about economic impact..." 
                      className="w-full h-12 pl-4 pr-12 bg-slate-800/50 border border-slate-700 rounded-xl text-sm text-white focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                    />
                    <button 
                      onClick={handleSendMessage}
                      className="absolute right-2 top-1/2 -translate-y-1/2 size-8 rounded-lg bg-blue-600 text-white flex items-center justify-center hover:bg-blue-500 transition-colors"
                    >
                      <Send size={16} />
                    </button>
                  </div>
                  <button 
                    onClick={startListening}
                    className={`size-12 rounded-xl border flex items-center justify-center transition-all ${
                      isListening ? 'bg-rose-500 border-rose-400 text-white animate-pulse' : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:text-white'
                    }`}
                  >
                    {isListening ? <MicOff size={20} /> : <Mic size={20} />}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default NewsDetailModal;
