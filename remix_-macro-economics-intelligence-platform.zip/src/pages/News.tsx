import React, { useState, useMemo } from 'react';
import { Newspaper, Search, Filter, Share2, Bookmark, Clock, ExternalLink, X, Brain, Save, Sparkles, AlertTriangle, Volume2, VolumeX, MessageSquare, Send } from 'lucide-react';
import { useSearch } from '../contexts/SearchContext';
import { useInstitutionalMemory, StoredNews } from '../contexts/InstitutionalMemoryContext';
import { useCollaboration } from '../contexts/CollaborationContext';
import NewsDetailModal from '../components/NewsDetailModal';

const NewsCard = ({ news, onAnalyze, onSave, isSaved, onShare }: { news: any, onAnalyze: (n: any) => void, onSave: (n: any) => void, isSaved: boolean, onShare: (n: any) => void }) => {
  const [isReading, setIsReading] = useState(false);
  const { sendMessage } = useCollaboration();
  const importanceColor = news.importance === 'high' ? 'border-rose-500/50 bg-rose-500/5' : 'border-slate-800/50';
  
  const toggleReadAloud = () => {
    if (isReading) {
      window.speechSynthesis.cancel();
      setIsReading(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(`${news.title}. ${news.summary}`);
      utterance.onend = () => setIsReading(false);
      window.speechSynthesis.speak(utterance);
      setIsReading(true);
    }
  };

  const handleShareToChat = () => {
    sendMessage(`Shared News: ${news.title}`, 'general', { type: 'news_share', news });
    onShare(news);
  };
  
  return (
    <div className={`rounded-2xl border overflow-hidden flex flex-col md:flex-row hover:border-blue-500/30 transition-all group ${importanceColor}`}>
      <div className="h-48 md:h-auto md:w-64 bg-slate-800 relative flex-shrink-0">
        <img 
          src={news.image} 
          alt={news.title} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-3 left-3 px-2 py-1 bg-blue-600 text-white text-[10px] font-bold rounded uppercase shadow-lg">
          {news.category}
        </div>
        <button 
          onClick={toggleReadAloud}
          className="absolute bottom-3 right-3 size-10 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center text-white hover:bg-blue-600 transition-all"
          title="Hands-free Mode"
        >
          {isReading ? <VolumeX size={18} /> : <Volume2 size={18} />}
        </button>
      </div>
      <div className="p-6 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
            <span>{news.source}</span>
            <span>•</span>
            <span className="flex items-center gap-1"><Clock size={12} /> {news.time}</span>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => onSave(news)}
              className={`transition-colors ${isSaved ? 'text-blue-500' : 'text-slate-500 hover:text-white'}`}
            >
              <Save size={16} />
            </button>
            <button 
              onClick={handleShareToChat}
              className="text-slate-500 hover:text-white transition-colors"
              title="Share to Group Chat"
            >
              <MessageSquare size={16} />
            </button>
            <button className="text-slate-500 hover:text-white transition-colors"><Share2 size={16} /></button>
          </div>
        </div>
        <h3 className="text-xl font-bold text-white mb-3 leading-tight group-hover:text-blue-400 transition-colors">{news.title}</h3>
        <p className="text-sm text-slate-400 leading-relaxed mb-6 line-clamp-2 md:line-clamp-3">
          {news.summary}
        </p>
        <div className="mt-auto flex items-center justify-between">
          <div className="flex gap-2">
            {news.importance === 'high' && (
              <span className="text-[9px] font-bold text-rose-500 bg-rose-500/10 px-2 py-1 rounded uppercase tracking-tighter flex items-center gap-1">
                <AlertTriangle size={10} /> High Impact
              </span>
            )}
            <span className="text-[9px] font-bold text-slate-500 bg-slate-800 px-2 py-1 rounded uppercase tracking-tighter">
              #{news.category}
            </span>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => onAnalyze(news)}
              className="text-xs font-bold text-blue-500 flex items-center gap-1 hover:underline"
            >
              AI Analysis <Sparkles size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const ALL_NEWS = [
  {
    id: 'n1',
    title: "March 2026: Global Semiconductor Output Hits Critical Low",
    summary: "Supply chain reports from Taiwan and South Korea indicate a 25% drop in high-end chip production for March 2026. This unexpected contraction is expected to ripple through global automotive and consumer tech sectors by Q3.",
    source: "REUTERS",
    time: "LIVE • MARCH 08, 2026",
    category: "Technology",
    importance: 'high',
    image: "https://picsum.photos/seed/chips/800/600"
  },
  {
    id: 'n2',
    title: "Fed Minutes Reveal 'Deep Concern' Over March Inflation Spike",
    summary: "The Federal Reserve's latest internal briefing notes a surprising 0.6% jump in core services inflation for early March 2026. Markets are now pricing in a 40% chance of a surprise rate hike in the next meeting.",
    source: "BLOOMBERG",
    time: "1 HOUR AGO • MARCH 08, 2026",
    category: "Monetary Policy",
    importance: 'high',
    image: "https://picsum.photos/seed/fed/800/600"
  },
  {
    id: 'n3',
    title: "Germany Announces Emergency Energy Rationing Plan for Industry",
    summary: "Following the escalation in EMEA energy supply disruptions, the German government has activated 'Level 2' of its emergency gas plan. Industrial output is projected to fall by 4.2% in March 2026.",
    source: "FINANCIAL TIMES",
    time: "3 HOURS AGO • MARCH 08, 2026",
    category: "Energy",
    importance: 'high',
    image: "https://picsum.photos/seed/germany/800/600"
  },
  {
    id: 'n4',
    title: "Goldman Sachs Upgrades 2026 Global Growth Forecast to 3.1%",
    summary: "Citing robust consumer spending in emerging markets and a faster-than-expected recovery in global trade, GS analysts have raised their outlook for the remainder of 2026.",
    source: "GOLDMAN SACHS",
    time: "5 HOURS AGO • MARCH 08, 2026",
    category: "Growth",
    importance: 'medium',
    image: "https://picsum.photos/seed/goldman/800/600"
  }
];

const News = () => {
  const { searchQuery, setSearchQuery } = useSearch();
  const { saveNews, storedNews, userInterests } = useInstitutionalMemory();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [visibleCount, setVisibleCount] = useState(4);
  const [selectedNews, setSelectedNews] = useState<any>(null);

  const categories = ['All', 'Inflation', 'Monetary Policy', 'Growth', 'Energy', 'Technology'];

  const filteredNews = useMemo(() => {
    return ALL_NEWS.filter(item => {
      const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           item.summary.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const displayedNews = filteredNews.slice(0, visibleCount);

  // AI Suggestions based on user interests
  const suggestedNews = useMemo(() => {
    return ALL_NEWS.filter(n => userInterests.includes(n.category)).slice(0, 2);
  }, [userInterests]);

  const handleSave = (news: any) => {
    const stored: StoredNews = {
      ...news,
      relevanceScore: 85,
      savedAt: new Date().toISOString(),
      keywords: [news.category, 'Macro', 'Market'],
      impactData: []
    };
    saveNews(stored);
  };

  const handleShare = (news: any) => {
    // In a real app, this would send a WebSocket message
    alert(`Shared "${news.title}" to Global Strategy group chat.`);
  };

  return (
    <div className="px-6 md:px-8 space-y-8">
      <section className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Newspaper className="text-blue-500" size={24} />
            <h1 className="text-2xl font-bold text-white">Macro News Feed</h1>
          </div>
          <p className="text-slate-400 text-sm">
            Real-time global macroeconomic news from Bloomberg, Reuters, and FT.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
            {categories.map(cat => (
              <button 
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  setVisibleCount(4);
                }}
                className={`h-10 px-4 rounded-xl text-xs font-bold transition-all whitespace-nowrap border ${
                  selectedCategory === cat 
                    ? 'bg-blue-600 border-blue-500 text-white' 
                    : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* AI Recommendations */}
      {suggestedNews.length > 0 && !searchQuery && (
        <section className="bg-blue-600/5 border border-blue-500/20 rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4 text-blue-500">
            <Brain size={18} />
            <h2 className="text-sm font-bold uppercase tracking-widest">AI Recommendations For You</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {suggestedNews.map((news, i) => (
              <div key={i} className="bg-[#141b26] p-4 rounded-xl border border-slate-800/50 flex gap-4 cursor-pointer hover:border-blue-500/30 transition-all" onClick={() => setSelectedNews(news)}>
                <img src={news.image} className="size-16 rounded-lg object-cover" alt="" referrerPolicy="no-referrer" />
                <div>
                  <h4 className="text-sm font-bold text-white line-clamp-1">{news.title}</h4>
                  <p className="text-xs text-slate-500 mt-1">Based on your interest in {news.category}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* News Grid */}
      <section className="space-y-6">
        {displayedNews.length > 0 ? (
          displayedNews.map((news, i) => (
            <NewsCard 
              key={news.id} 
              news={news} 
              onAnalyze={setSelectedNews}
              onSave={handleSave}
              onShare={handleShare}
              isSaved={storedNews.some(n => n.id === news.id)}
            />
          ))
        ) : (
          <div className="py-20 text-center">
            <div className="size-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-4 text-slate-500">
              <Search size={32} />
            </div>
            <h3 className="text-lg font-bold text-white">No news found</h3>
            <p className="text-slate-400 text-sm mt-1">Try adjusting your search or category filters.</p>
          </div>
        )}
      </section>

      {visibleCount < filteredNews.length && (
        <div className="flex justify-center py-8">
          <button 
            onClick={() => setVisibleCount(prev => prev + 2)}
            className="px-8 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-sm font-bold text-slate-400 hover:text-white transition-colors"
          >
            Load More News
          </button>
        </div>
      )}

      <NewsDetailModal 
        isOpen={!!selectedNews} 
        onClose={() => setSelectedNews(null)} 
        news={selectedNews} 
      />
    </div>
  );
};

export default News;
