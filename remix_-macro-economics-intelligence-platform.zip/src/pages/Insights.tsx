import React, { useMemo } from 'react';
import { Lightbulb, TrendingUp, TrendingDown, AlertTriangle, ArrowRight, ShieldCheck, Zap, Search } from 'lucide-react';
import { useSearch } from '../contexts/SearchContext';

const InsightCard = ({ title, category, sentiment, summary, details, date }: { title: string, category: string, sentiment: 'Bullish' | 'Bearish' | 'Neutral', summary: string, details: string, date: string }) => (
  <div className="bg-[#141b26] p-6 rounded-2xl border border-slate-800/50 hover:border-blue-500/30 transition-all group">
    <div className="flex items-start justify-between mb-4">
      <div className="flex gap-4">
        <div className="bg-blue-600/10 p-3 rounded-xl text-blue-500">
          <Zap size={24} />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white group-hover:text-blue-400 transition-colors">{title}</h3>
          <div className="flex items-center gap-3 mt-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{category}</span>
            <span className="text-[10px] font-bold text-slate-500">•</span>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{date}</span>
          </div>
        </div>
      </div>
      <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase ${
        sentiment === 'Bullish' ? 'bg-emerald-500/10 text-emerald-500' : 
        sentiment === 'Bearish' ? 'bg-rose-500/10 text-rose-500' : 
        'bg-amber-500/10 text-amber-500'
      }`}>
        {sentiment}
      </span>
    </div>
    <p className="text-sm font-bold text-slate-300 mb-2">{summary}</p>
    <p className="text-sm text-slate-400 leading-relaxed mb-6">{details}</p>
    <div className="flex items-center justify-between pt-4 border-t border-slate-800">
      <div className="flex items-center gap-4">
        <button className="text-[10px] font-bold text-slate-500 hover:text-white transition-colors flex items-center gap-1">
          <ShieldCheck size={14} /> Verify Source
        </button>
      </div>
      <button className="text-xs font-bold text-blue-500 flex items-center gap-1 hover:underline">
        Full Analysis <ArrowRight size={14} />
      </button>
    </div>
  </div>
);

const ALL_INSIGHTS = [
  {
    title: "AI Sector Growth Sustainability",
    category: "Technology",
    sentiment: "Bullish" as const,
    summary: "Infrastructure providers continue to outpace expectations despite high valuations.",
    details: "The 'macro bubble' concerns are mitigated by healthy cash reserves in top-tier tech firms. NVDA and MSFT earnings growth suggests sustained CAPEX cycles.",
    date: "2 HOURS AGO"
  },
  {
    title: "European Energy Stability",
    category: "Energy",
    sentiment: "Neutral" as const,
    summary: "Natural gas reserves across the EU are at 85% capacity, stabilizing manufacturing.",
    details: "Macro indicators suggest a stabilizing manufacturing sector in Germany, though inflation remains a persistent drag on consumer spending power.",
    date: "5 HOURS AGO"
  },
  {
    title: "Bond Market Inversion Risks",
    category: "Monetary Policy",
    sentiment: "Bearish" as const,
    summary: "The yield curve remains inverted, traditionally a precursor to recession.",
    details: "Analysts are monitoring the 10-year Treasury closely as it tests psychological resistance levels at 4.5%. Term premium is returning to the market.",
    date: "1 DAY AGO"
  },
  {
    title: "Emerging Markets Liquidity",
    category: "Forex",
    sentiment: "Neutral" as const,
    summary: "USD strength is creating headwind for EM debt servicing.",
    details: "While some EM economies show resilience, the sustained 'higher for longer' Fed stance is tightening financial conditions globally.",
    date: "2 DAYS AGO"
  }
];

const Insights = () => {
  const { searchQuery, setSearchQuery } = useSearch();

  const filteredInsights = useMemo(() => {
    return ALL_INSIGHTS.filter(item => 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      item.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  return (
    <div className="px-6 md:px-8 space-y-8">
      <section>
        <div className="flex items-center gap-3 mb-2">
          <Lightbulb className="text-blue-500" size={24} />
          <h1 className="text-2xl font-bold text-white">AI Macro Insights</h1>
        </div>
        <p className="text-slate-400 text-sm max-w-2xl">
          Deep neural analysis of global market data, sentiment, and policy shifts. Updated in real-time as new data points emerge.
        </p>
      </section>

      {/* Featured Insight */}
      {!searchQuery && (
        <section className="bg-gradient-to-br from-blue-600/20 to-indigo-600/5 border border-blue-500/20 rounded-2xl p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Lightbulb size={120} className="text-blue-500" />
          </div>
          <div className="relative z-10 max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-2 py-1 bg-blue-500 text-white text-[10px] font-bold rounded uppercase">Featured Analysis</span>
              <span className="text-xs font-bold text-slate-400">Mar 20, 2024</span>
            </div>
            <h2 className="text-3xl font-bold text-white mb-4 leading-tight">The "Soft Landing" Paradox: Resilient Growth vs. Sticky Inflation</h2>
            <p className="text-lg text-slate-300 mb-6 leading-relaxed">
              Our latest models suggest a 62% probability of a soft landing, but the path is narrowing. High real rates are finally impacting corporate margins, yet labor markets remain historically tight.
            </p>
            <div className="flex gap-4">
              <button className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-500 transition-colors shadow-lg shadow-blue-600/20">
                Read Deep Dive
              </button>
              <button className="bg-slate-800/50 border border-slate-700 text-white px-6 py-3 rounded-xl font-bold hover:bg-slate-800 transition-colors">
                View Data Model
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Insight Feed */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">
            {searchQuery ? `Search Results for "${searchQuery}"` : 'Recent Analysis'}
          </h2>
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="text-xs font-bold text-blue-500 hover:underline"
            >
              Clear Search
            </button>
          )}
        </div>
        
        {filteredInsights.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredInsights.map((insight, i) => (
              <InsightCard key={i} {...insight} />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center bg-[#141b26] rounded-2xl border border-slate-800/50">
            <div className="size-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-4 text-slate-500">
              <Search size={32} />
            </div>
            <h3 className="text-lg font-bold text-white">No insights found</h3>
            <p className="text-slate-400 text-sm mt-1">Try a different search term or browse featured analysis.</p>
          </div>
        )}
      </section>
    </div>
  );
};

export default Insights;
