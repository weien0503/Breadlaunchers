import React, { useState } from 'react';
import { Database, Search, Trash2, ExternalLink, Sparkles, Brain, Clock, AlertTriangle, Info, Highlighter } from 'lucide-react';
import { useInstitutionalMemory, StoredNews } from '../contexts/InstitutionalMemoryContext';
import NewsDetailModal from '../components/NewsDetailModal';

const InstitutionalMemory = () => {
  const { storedNews, removeNews } = useInstitutionalMemory();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedNews, setSelectedNews] = useState<any>(null);

  const filteredNews = storedNews.filter(n => 
    n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.summary.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="px-6 md:px-8 space-y-8">
      <section className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Database className="text-blue-500" size={24} />
            <h1 className="text-2xl font-bold text-white">Institutional Memory</h1>
          </div>
          <p className="text-slate-400 text-sm">
            Compiled repository of market-moving events and historical discussions for long-term tracking.
          </p>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search memory..." 
            className="h-10 pl-10 pr-4 bg-slate-800/50 border border-slate-700 rounded-xl text-xs font-medium focus:ring-2 focus:ring-blue-500/20 outline-none transition-all text-white w-64"
          />
        </div>
      </section>

      {storedNews.length === 0 ? (
        <div className="py-32 text-center bg-[#141b26] rounded-3xl border border-dashed border-slate-800">
          <div className="size-20 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-6 text-slate-500">
            <Brain size={40} />
          </div>
          <h3 className="text-xl font-bold text-white">Your memory is empty</h3>
          <p className="text-slate-400 text-sm mt-2 max-w-md mx-auto">
            Save important news from the feed to build your institutional knowledge base and track long-term macro trends.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {filteredNews.map((news) => (
            <div 
              key={news.id} 
              className={`bg-[#141b26] p-6 rounded-2xl border transition-all hover:border-blue-500/30 group relative ${
                news.importance === 'high' ? 'border-rose-500/30 bg-rose-500/5' : 'border-slate-800/50'
              }`}
            >
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                        news.importance === 'high' ? 'bg-rose-500/20 text-rose-500' : 'bg-emerald-500/20 text-emerald-500'
                      }`}>
                        {news.importance === 'high' ? 'High Intensity' : 'Informational'}
                      </span>
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1">
                        <Clock size={12} /> Saved {new Date(news.savedAt).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => setSelectedNews(news)}
                        className="p-2 rounded-lg bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-blue-500 transition-colors"
                      >
                        <Sparkles size={16} />
                      </button>
                      <button 
                        onClick={() => removeNews(news.id)}
                        className="p-2 rounded-lg bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-rose-500 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-3 leading-tight">{news.title}</h3>
                  
                  {/* Keyword Highlighting Simulation */}
                  <div className="text-sm text-slate-400 leading-relaxed mb-6">
                    {news.summary.split(' ').map((word, i) => {
                      const isKeyword = news.keywords.some(k => word.toLowerCase().includes(k.toLowerCase()));
                      return (
                        <span key={i} className={isKeyword ? 'bg-blue-500/20 text-blue-400 px-1 rounded font-bold' : ''}>
                          {word}{' '}
                        </span>
                      );
                    })}
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {news.keywords.map((tag, i) => (
                      <span key={i} className="text-[10px] font-bold text-slate-500 bg-slate-800 px-2 py-1 rounded uppercase flex items-center gap-1">
                        <Highlighter size={10} /> {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="md:w-64 space-y-4">
                  <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-800/50">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                      {news.importance === 'high' ? <AlertTriangle size={12} className="text-rose-500" /> : <Info size={12} className="text-emerald-500" />}
                      Impact Assessment
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-slate-400">Relevance</span>
                        <span className="text-xs font-bold text-white">{news.relevanceScore}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${news.importance === 'high' ? 'bg-rose-500' : 'bg-emerald-500'}`} 
                          style={{ width: `${news.relevanceScore}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => setSelectedNews(news)}
                    className="w-full py-3 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-500 transition-all flex items-center justify-center gap-2"
                  >
                    Open Analysis <ExternalLink size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <NewsDetailModal 
        isOpen={!!selectedNews} 
        onClose={() => setSelectedNews(null)} 
        news={selectedNews} 
      />
    </div>
  );
};

export default InstitutionalMemory;
