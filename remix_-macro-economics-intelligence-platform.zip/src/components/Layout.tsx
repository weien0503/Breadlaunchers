import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Lightbulb, Newspaper, Cpu, Bell, Search, User, X, Sparkles, TrendingUp, Clock, Database, Users, Mic, MicOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { useSearch } from '../contexts/SearchContext';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const Navigation = () => {
  const location = useLocation();

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'Insights', path: '/insights', icon: Lightbulb },
    { name: 'News', path: '/news', icon: Newspaper },
    { name: 'Simulator', path: '/simulator', icon: Cpu },
    { name: 'Memory Bank', path: '/memory', icon: Database },
    { name: 'Collaboration', path: '/collaboration', icon: Users },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#141b26]/95 backdrop-blur-md border-t border-slate-800 px-6 pb-8 pt-3 flex justify-between items-center md:relative md:flex-col md:w-64 md:h-screen md:border-t-0 md:border-r md:px-4 md:pt-8 md:pb-8 md:bg-[#0a0e14]">
      <div className="hidden md:flex items-center gap-3 mb-12 px-2">
        <div className="size-10 rounded-lg bg-blue-600/20 flex items-center justify-center text-blue-500">
          <LayoutDashboard size={24} />
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight text-white">Macro Intel</h1>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Global Markets</p>
        </div>
      </div>

      <div className="flex w-full justify-between md:flex-col md:gap-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex flex-col items-center gap-1 transition-colors md:flex-row md:px-4 md:py-3 md:rounded-xl md:gap-3",
                isActive ? "text-blue-500 md:bg-blue-600/10" : "text-slate-400 hover:text-slate-200"
              )}
            >
              <Icon size={20} className={cn(isActive && "fill-blue-500/20")} />
              <span className="text-[10px] font-bold uppercase tracking-widest md:text-sm md:normal-case md:tracking-normal md:font-medium">
                {item.name}
              </span>
            </Link>
          );
        })}
      </div>

      <div className="hidden md:mt-auto md:flex flex-col gap-4 w-full px-2">
        <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
          <p className="text-xs font-bold text-slate-400 uppercase mb-2">Risk Level</p>
          <div className="flex items-center gap-2">
            <div className="h-2 flex-1 bg-slate-700 rounded-full overflow-hidden">
              <div className="h-full w-[78%] bg-red-500"></div>
            </div>
            <span className="text-xs font-bold text-red-500">78%</span>
          </div>
        </div>
      </div>
    </nav>
  );
};

const Header = () => {
  const { searchQuery, setSearchQuery } = useSearch();
  const [isFocused, setIsFocused] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [hasUnread, setHasUnread] = useState(true);
  const searchRef = useRef<HTMLDivElement>(null);

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }
    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setSearchQuery(transcript);
      setIsFocused(true);
    };
    recognition.start();
  };

  const trendingSearches = [
    { text: "Fed Interest Rate Decision Probability", icon: TrendingUp },
    { text: "S&P 500 Year-to-Date Performance", icon: TrendingUp },
    { text: "Impact of Oil Prices on Airline Stocks", icon: Sparkles },
    { text: "China Manufacturing PMI Trends", icon: Clock },
    { text: "Bitcoin Correlation with Tech Stocks", icon: Sparkles },
    { text: "Global Inflation Forecast 2026", icon: Clock },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="flex items-center justify-between px-6 py-6 md:px-8 relative z-50">
      <div className="flex items-center gap-4 md:hidden">
        <div className="size-10 rounded-full bg-blue-600/10 flex items-center justify-center text-blue-500 overflow-hidden">
          <img 
            src="https://picsum.photos/seed/user/100/100" 
            alt="User" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight text-white">Macro Intel</h1>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Global Markets</p>
        </div>
      </div>
      
      <div className="hidden md:flex items-center gap-4 flex-1 max-w-xl" ref={searchRef}>
        <div className="relative w-full">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
            <Search className="text-slate-500" size={18} />
            {isFocused && !searchQuery && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-1.5 px-1.5 py-0.5 bg-blue-600/20 rounded text-[10px] font-bold text-blue-500 uppercase tracking-widest"
              >
                <Sparkles size={10} /> AI Prompt
              </motion.div>
            )}
          </div>
          <input 
            type="text" 
            value={searchQuery}
            onFocus={() => setIsFocused(true)}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isFocused ? "Ask anything about global markets..." : "Search indices, assets, or events..."} 
            className={cn(
              "w-full h-11 pr-24 bg-slate-800/50 border border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-white",
              isFocused && !searchQuery ? "pl-32" : "pl-12"
            )}
          />
          <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="text-slate-500 hover:text-white"
              >
                <X size={16} />
              </button>
            )}
            <button 
              onClick={startListening}
              className={cn(
                "p-1.5 rounded-lg transition-all",
                isListening ? "bg-rose-500 text-white animate-pulse" : "text-slate-500 hover:text-white hover:bg-slate-800"
              )}
            >
              {isListening ? <MicOff size={16} /> : <Mic size={16} />}
            </button>
          </div>

          <AnimatePresence>
            {isFocused && !searchQuery && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute top-full left-0 right-0 mt-2 bg-[#141b26] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl"
              >
                <div className="p-4 border-b border-slate-800/50">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                      <TrendingUp size={12} /> Trending AI Suggestions
                    </h3>
                    <span className="text-[10px] font-medium text-slate-600">Powered by Gemini</span>
                  </div>
                  <div className="grid grid-cols-1 gap-1">
                    {trendingSearches.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setSearchQuery(item.text);
                          setIsFocused(false);
                        }}
                        className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-slate-800/50 text-left transition-colors group"
                      >
                        <div className="size-8 rounded-lg bg-slate-800 flex items-center justify-center text-slate-500 group-hover:text-blue-500 group-hover:bg-blue-500/10 transition-colors">
                          <item.icon size={16} />
                        </div>
                        <span className="text-sm text-slate-300 group-hover:text-white transition-colors">{item.text}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div className="p-3 bg-blue-600/5 flex items-center justify-center">
                  <p className="text-[10px] text-slate-500 font-medium">Try asking: "What is the current macro risk score for the EU?"</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button 
          onClick={() => setHasUnread(false)}
          className="size-10 rounded-xl flex items-center justify-center bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-colors relative"
        >
          <Bell size={20} />
          {hasUnread && (
            <span className="absolute top-2 right-2 size-2 bg-rose-500 rounded-full animate-pulse border-2 border-[#0a0e14]" />
          )}
        </button>
        <button className="hidden md:flex size-10 rounded-xl items-center justify-center bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white transition-colors">
          <User size={20} />
        </button>
      </div>
    </header>
  );
};

export const Layout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-[#0a0e14]">
      <Navigation />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 overflow-y-auto no-scrollbar pb-24 md:pb-8">
          {children}
        </main>
      </div>
    </div>
  );
};
