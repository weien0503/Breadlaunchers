import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface ChartData {
  type: 'line' | 'bar' | 'area' | 'pie';
  title: string;
  data: any[];
  xAxisKey: string;
  series: { key: string; color: string; name: string }[];
}

export interface AgentResponse {
  text: string;
  chart?: ChartData;
  sources?: { uri: string; title: string }[];
}

export const askMacroAgent = async (prompt: string, history: any[] = []): Promise<AgentResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history,
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            text: {
              type: Type.STRING,
              description: "The textual response to the user's query, citing sources where appropriate.",
            },
            chart: {
              type: Type.OBJECT,
              description: "Optional chart data if the response benefits from visualization.",
              properties: {
                type: { type: Type.STRING, enum: ['line', 'bar', 'area', 'pie'] },
                title: { type: Type.STRING },
                xAxisKey: { type: Type.STRING },
                data: {
                  type: Type.ARRAY,
                  items: { type: Type.OBJECT, properties: {}, additionalProperties: true }
                },
                series: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      key: { type: Type.STRING },
                      color: { type: Type.STRING },
                      name: { type: Type.STRING }
                    }
                  }
                }
              },
              required: ['type', 'title', 'data', 'xAxisKey', 'series']
            }
          },
          required: ['text']
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    
    // Extract grounding sources
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.map(chunk => chunk.web)
      .filter(web => web) as { uri: string; title: string }[] | undefined;

    return {
      text: result.text,
      chart: result.chart,
      sources: sources
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      text: "I encountered an error while processing your request. Please try again later.",
    };
  }
};

export const analyzeNews = async (news: any): Promise<{ summary: string; impactData: any[] }> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze the following news for its macro economic impact:
      Title: ${news.title}
      Summary: ${news.summary}
      Category: ${news.category}
      Source: ${news.source}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING, description: "A concise executive summary of the macro impact." },
            impactData: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "Time period (e.g., T, T+1, etc.)" },
                  value: { type: Type.NUMBER, description: "Predicted impact value (normalized 0-100 or absolute)" }
                }
              }
            }
          },
          required: ['summary', 'impactData']
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini News Analysis Error:", error);
    return {
      summary: "Unable to generate AI summary at this time.",
      impactData: []
    };
  }
};
