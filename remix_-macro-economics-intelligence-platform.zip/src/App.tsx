import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import Dashboard from './pages/Dashboard';
import Insights from './pages/Insights';
import News from './pages/News';
import Simulator from './pages/Simulator';
import InstitutionalMemory from './pages/InstitutionalMemory';
import Collaboration from './pages/Collaboration';
import { SearchProvider } from './contexts/SearchContext';
import { InstitutionalMemoryProvider } from './contexts/InstitutionalMemoryContext';
import { CollaborationProvider } from './contexts/CollaborationContext';

export default function App() {
  return (
    <InstitutionalMemoryProvider>
      <CollaborationProvider>
        <SearchProvider>
          <Router>
            <Layout>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/insights" element={<Insights />} />
                <Route path="/news" element={<News />} />
                <Route path="/simulator" element={<Simulator />} />
                <Route path="/memory" element={<InstitutionalMemory />} />
                <Route path="/collaboration" element={<Collaboration />} />
              </Routes>
            </Layout>
          </Router>
        </SearchProvider>
      </CollaborationProvider>
    </InstitutionalMemoryProvider>
  );
}
