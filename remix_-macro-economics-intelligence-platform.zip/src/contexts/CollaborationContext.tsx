import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

import { ChartData } from '../services/geminiService';

export interface Message {
  id: string;
  user: string;
  text: string;
  timestamp: string;
  room: string;
  chart?: ChartData;
  sources?: { uri: string; title: string }[];
  isAi?: boolean;
  metadata?: any;
}

interface CollaborationContextType {
  messages: Message[];
  sendMessage: (text: string, room: string, metadata?: any) => void;
  activeRoom: string;
  setActiveRoom: (room: string) => void;
}

const CollaborationContext = createContext<CollaborationContextType | undefined>(undefined);

export const CollaborationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeRoom, setActiveRoom] = useState('general');
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = new WebSocket(`${protocol}//${window.location.host}`);
    socketRef.current = socket;

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'INIT_MESSAGES') {
        setMessages(data.payload);
      } else if (data.type === 'NEW_MESSAGE') {
        setMessages((prev) => [...prev, data.payload]);
      }
    };

    return () => {
      socket.close();
    };
  }, []);

  const sendMessage = (text: string, room: string, metadata?: any) => {
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) return;

    const payload = {
      user: 'Asset Manager',
      text,
      room,
      metadata
    };

    socketRef.current.send(JSON.stringify({ type: 'SEND_MESSAGE', payload }));
  };

  return (
    <CollaborationContext.Provider value={{ messages, sendMessage, activeRoom, setActiveRoom }}>
      {children}
    </CollaborationContext.Provider>
  );
};

export const useCollaboration = () => {
  const context = useContext(CollaborationContext);
  if (!context) {
    throw new Error('useCollaboration must be used within a CollaborationProvider');
  }
  return context;
};
