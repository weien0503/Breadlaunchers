import React, { useState, useMemo } from 'react';
import { Cpu, Info, Play, RotateCcw, TrendingUp, TrendingDown, Minus } from 'lucide-react';

const Slider = ({ label, value, min, max, step, unit, onChange }: { label: string, value: number, min: number, max: number, step: number, unit: string, onChange: (v: number) => void }) => (
  <div className="bg-[#141b26] p-5 rounded-2xl border border-slate-800/50 shadow-sm">
    <div className="flex w-full items-center justify-between mb-4">
      <div className="flex items-center gap-1.5">
        <p className="text-slate-200 text-sm font-bold uppercase tracking-wider">{label}</p>
        <Info size={14} className="text-slate-500 cursor-help" />
      </div>
      <div className="flex items-center gap-2">
        <span className="text-blue-500 text-sm font-bold">{value}{unit}</span>
      </div>
    </div>
    <div className="relative flex h-6 w-full items-center">
      <input 
        type="range" 
        min={min} 
        max={max} 
        step={step} 
        value={value} 
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-blue-500"
      />
    </div>
    <div className="flex justify-between mt-2 text-[10px] text-slate-500 font-bold uppercase tracking-tighter">
      <span>{min}{unit}</span>
      <span>{max}{unit}</span>
    </div>
  </div>
);

const ImpactCard = ({ title, impact, color, icon: Icon }: { title: string, impact: string, color: string, icon: any }) => (
  <div className="bg-[#141b26] p-4 rounded-xl border border-slate-800/50 flex items-center justify-between">
    <div className="flex items-center gap-3">
      <div className={`size-10 rounded-lg flex items-center justify-center ${color.replace('text-', 'bg-').replace('500', '500/10')}`}>
        <Icon size={20} className={color} />
      </div>
      <span className="font-bold text-white text-sm">{title}</span>
    </div>
    <span className={`text-xs font-bold uppercase tracking-widest ${color}`}>
      {impact}
    </span>
  </div>
);

const Simulator = () => {
  const [interestRate, setInterestRate] = useState(4.5);
  const [gdpGrowth, setGdpGrowth] = useState(2.1);
  const [oilPrice, setOilPrice] = useState(78.5);
  const [qeEnabled, setQeEnabled] = useState(false);
  const [geopoliticalTension, setGeopoliticalTension] = useState(true);

  const simulationResult = useMemo(() => {
    // Mock simulation logic
    let score = 0;
    score += (gdpGrowth - 2) * 2;
    score -= (interestRate - 4) * 1.5;
    score -= (oilPrice - 70) * 0.1;
    if (qeEnabled) score += 5;
    if (geopoliticalTension) score -= 8;

    const result = score > 5 ? 'Strong Bullish' : score > 0 ? 'Bullish' : score > -5 ? 'Neutral' : 'Bearish';
    const percent = (score * 0.5).toFixed(1);
    
    return { result, percent, score };
  }, [interestRate, gdpGrowth, oilPrice, qeEnabled, geopoliticalTension]);

  const getImpact = (baseScore: number, multiplier: number) => {
    const val = baseScore * multiplier;
    if (val > 5) return { impact: 'Strong Growth', color: 'text-emerald-500', icon: TrendingUp };
    if (val > 1) return { impact: 'Moderate Growth', color: 'text-emerald-400', icon: TrendingUp };
    if (val > -1) return { impact: 'Stable', color: 'text-slate-400', icon: Minus };
    if (val > -5) return { impact: 'Moderate Decline', color: 'text-rose-400', icon: TrendingDown };
    return { impact: 'Strong Decline', color: 'text-rose-500', icon: TrendingDown };
  };

  const reset = () => {
    setInterestRate(4.5);
    setGdpGrowth(2.1);
    setOilPrice(78.5);
    setQeEnabled(false);
    setGeopoliticalTension(true);
  };

  return (
    <div className="px-6 md:px-8 space-y-8">
      <section>
        <div className="flex items-center gap-3 mb-2">
          <Cpu className="text-blue-500" size={24} />
          <h1 className="text-2xl font-bold text-white">Macro Scenario Simulator</h1>
        </div>
        <p className="text-slate-400 text-sm max-w-2xl">
          Adjust macroeconomic variables to see predicted impacts on global asset classes based on our proprietary AI data models.
        </p>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Input Variables</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Slider 
              label="Interest Rates" 
              value={interestRate} 
              min={0} 
              max={10} 
              step={0.25} 
              unit="%" 
              onChange={setInterestRate} 
            />
            <Slider 
              label="GDP Growth" 
              value={gdpGrowth} 
              min={-5} 
              max={5} 
              step={0.1} 
              unit="%" 
              onChange={setGdpGrowth} 
            />
            <Slider 
              label="Oil Price" 
              value={oilPrice} 
              min={30} 
              max={150} 
              step={1} 
              unit="$" 
              onChange={setOilPrice} 
            />
            <div className="bg-[#141b26] p-5 rounded-2xl border border-slate-800/50 shadow-sm flex flex-col justify-center gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-white">Quantitative Easing</p>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter">Central Bank Purchases</p>
                </div>
                <button 
                  onClick={() => setQeEnabled(!qeEnabled)}
                  className={`w-10 h-5 rounded-full relative transition-colors ${qeEnabled ? 'bg-blue-600' : 'bg-slate-800'}`}
                >
                  <div className={`absolute top-0.5 size-4 bg-white rounded-full shadow-sm transition-all ${qeEnabled ? 'right-0.5' : 'left-0.5'}`}></div>
                </button>
              </div>
              <div className="h-px bg-slate-800"></div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-bold text-white">Geopolitical Tension</p>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter">Global Instability Risks</p>
                </div>
                <button 
                  onClick={() => setGeopoliticalTension(!geopoliticalTension)}
                  className={`w-10 h-5 rounded-full relative transition-colors ${geopoliticalTension ? 'bg-blue-600' : 'bg-slate-800'}`}
                >
                  <div className={`absolute top-0.5 size-4 bg-white rounded-full shadow-sm transition-all ${geopoliticalTension ? 'right-0.5' : 'left-0.5'}`}></div>
                </button>
              </div>
            </div>
          </div>
          
          <div className="flex gap-4">
            <button className="flex-1 bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2 hover:bg-blue-500 transition-colors">
              <Play size={18} /> Run Full Simulation
            </button>
            <button 
              onClick={reset}
              className="px-6 bg-slate-800/50 border border-slate-700 text-slate-400 py-4 rounded-2xl font-bold hover:text-white hover:bg-slate-800 transition-colors"
            >
              <RotateCcw size={18} />
            </button>
          </div>
        </div>

        {/* Results */}
        <div className="space-y-6">
          <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Projected Outcome</h2>
          <div className="bg-[#141b26] p-6 rounded-2xl border border-slate-800/50 shadow-sm">
            <div className="flex justify-between items-start mb-6">
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">S&P 500 Projection</p>
                <p className="text-3xl font-bold text-white mt-1">{simulationResult.percent}%</p>
              </div>
              <div className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                simulationResult.score > 0 ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'
              }`}>
                {simulationResult.result}
              </div>
            </div>

            <div className="h-40 flex items-end justify-between gap-1 px-2 mb-6">
              {[30, 45, 40, 60, 55, 80, 70].map((h, i) => (
                <div 
                  key={i} 
                  className={`w-full rounded-t-sm transition-all duration-500 ${i === 5 ? 'bg-blue-600' : 'bg-blue-600/20'}`}
                  style={{ height: `${h}%` }}
                >
                  {i === 5 && (
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-blue-500 whitespace-nowrap">Target</div>
                  )}
                </div>
              ))}
            </div>

            <div className="space-y-3">
              <ImpactCard title="Equities" {...getImpact(simulationResult.score, 1.2)} />
              <ImpactCard title="Bonds" {...getImpact(simulationResult.score, -0.8)} />
              <ImpactCard title="Commodities" {...getImpact(simulationResult.score, 0.5)} />
              <ImpactCard title="Currency (USD)" {...getImpact(simulationResult.score, 0.3)} />
            </div>
          </div>

          <div className="bg-blue-600/5 border border-blue-500/20 rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-2 text-blue-500">
              <Cpu size={14} />
              <span className="text-[10px] font-bold uppercase">AI Reasoning</span>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              Higher GDP growth expectations are offsetting the impact of sustained interest rates. Consumer spending remains resilient, suggesting a "soft landing" scenario where market indices maintain a positive trajectory despite tightening liquidity.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Simulator;
