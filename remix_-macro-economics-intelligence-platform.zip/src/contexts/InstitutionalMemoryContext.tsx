import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface StoredNews {
  id: string;
  title: string;
  summary: string;
  source: string;
  time: string;
  category: string;
  importance: 'high' | 'medium' | 'low';
  relevanceScore: number; // 0-100
  savedAt: string;
  keywords: string[];
  impactData: { name: string; value: number }[];
}

export interface MacroTheme {
  id: string;
  title: string;
  status: 'hot' | 'cold' | 'stable';
  priority: number; // 1-5
  riskImplications: string[];
  lastUpdated: string;
}

interface InstitutionalMemoryContextType {
  storedNews: StoredNews[];
  saveNews: (news: StoredNews) => void;
  removeNews: (id: string) => void;
  themes: MacroTheme[];
  updateThemePriority: (id: string, priority: number) => void;
  userInterests: string[];
  addUserInterest: (topic: string) => void;
}

const InstitutionalMemoryContext = createContext<InstitutionalMemoryContextType | undefined>(undefined);

export const InstitutionalMemoryProvider = ({ children }: { children: ReactNode }) => {
  const [storedNews, setStoredNews] = useState<StoredNews[]>([]);
  const [userInterests, setUserInterests] = useState<string[]>(['Inflation', 'AI Infrastructure']);
  
  const [themes, setThemes] = useState<MacroTheme[]>([
    {
      id: '1',
      title: 'Global Inflation Pivot',
      status: 'hot',
      priority: 5,
      riskImplications: [
        'Sustained high real rates impacting consumer discretionary',
        'Potential for wage-price spiral in service sectors',
        'Currency volatility in emerging markets'
      ],
      lastUpdated: '2024-03-20'
    },
    {
      id: '2',
      title: 'AI Infrastructure Supercycle',
      status: 'hot',
      priority: 4,
      riskImplications: [
        'Supply chain bottlenecks for advanced semiconductors',
        'Energy grid capacity constraints',
        'Valuation bubbles in mid-cap tech'
      ],
      lastUpdated: '2024-03-19'
    },
    {
      id: '3',
      title: 'EU Energy Transition',
      status: 'stable',
      priority: 3,
      riskImplications: [
        'Regulatory compliance costs for heavy industry',
        'Transition risks for traditional energy providers',
        'Strategic dependency on critical mineral imports'
      ],
      lastUpdated: '2026-03-08'
    },
    {
      id: '4',
      title: 'Global Semiconductor Shortage (March 2026)',
      status: 'hot',
      priority: 5,
      riskImplications: [
        'Production delays in high-end consumer electronics',
        'Inflationary pressure on automotive sector',
        'Strategic stockpiling by major tech firms'
      ],
      lastUpdated: '2026-03-05'
    },
    {
      id: '5',
      title: 'EMEA Energy Crisis Escalation',
      status: 'hot',
      priority: 4,
      riskImplications: [
        'Severe industrial output contraction in Germany',
        'Energy rationing risks for Q2 2026',
        'Fiscal deficit expansion due to energy subsidies'
      ],
      lastUpdated: '2026-03-07'
    }
  ]);

  const saveNews = (news: StoredNews) => {
    setStoredNews(prev => {
      if (prev.find(n => n.id === news.id)) return prev;
      return [news, ...prev];
    });
    // Track interest automatically
    addUserInterest(news.category);
  };

  const removeNews = (id: string) => {
    setStoredNews(prev => prev.filter(n => n.id !== id));
  };

  const updateThemePriority = (id: string, priority: number) => {
    setThemes(prev => prev.map(t => t.id === id ? { ...t, priority } : t));
  };

  const addUserInterest = (topic: string) => {
    setUserInterests(prev => {
      if (prev.includes(topic)) return prev;
      return [...prev, topic].slice(-10); // Keep last 10
    });
  };

  return (
    <InstitutionalMemoryContext.Provider value={{ 
      storedNews, 
      saveNews, 
      removeNews, 
      themes, 
      updateThemePriority,
      userInterests,
      addUserInterest
    }}>
      {children}
    </InstitutionalMemoryContext.Provider>
  );
};

export const useInstitutionalMemory = () => {
  const context = useContext(InstitutionalMemoryContext);
  if (context === undefined) {
    throw new Error('useInstitutionalMemory must be used within a InstitutionalMemoryProvider');
  }
  return context;
};
