import React, { useState } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, Calendar, ArrowRight, Shield, Activity, Flame, Snowflake, Star, Eye, Plus, Info, Clock, Sparkles, Loader2, X } from 'lucide-react';

const RiskFactorsModal = ({ isOpen, onClose, factors }: { isOpen: boolean, onClose: () => void, factors: any[] }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-[#141b26] w-full max-w-md rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-800/20">
          <div className="flex items-center gap-3">
            <AlertTriangle className="text-rose-500" size={24} />
            <h2 className="text-xl font-bold text-white">Risk Factors</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all">
            <X size={20} />
          </button>
        </div>
        <div className="p-6 space-y-4">
          {factors.map((factor, i) => (
            <div key={i} className="p-4 rounded-2xl bg-slate-800/30 border border-slate-800">
              <div className="flex justify-between items-center mb-2">
                <p className="text-sm font-bold text-white">{factor.name}</p>
                <span className={`text-[10px] font-bold px-2 py-1 rounded uppercase ${
                  factor.level === 'High' ? 'bg-rose-500/10 text-rose-500' : 'bg-amber-500/10 text-amber-500'
                }`}>
                  {factor.level}
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">{factor.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
import { useInstitutionalMemory } from '../contexts/InstitutionalMemoryContext';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { askMacroAgent } from '../services/geminiService';

const sentimentData = [
  { name: 'Mon', sentiment: 65, prediction: 65 },
  { name: 'Tue', sentiment: 68, prediction: 68 },
  { name: 'Wed', sentiment: 62, prediction: 62 },
  { name: 'Thu', sentiment: 70, prediction: 70 },
  { name: 'Fri', sentiment: 75, prediction: 75 },
  { name: 'Sat', sentiment: null, prediction: 78 },
  { name: 'Sun', sentiment: null, prediction: 82 },
  { name: 'Mon', sentiment: null, prediction: 80 },
];

const WatchlistCard = ({ symbol, price, change, isPositive }: { symbol: string, price: string, change: string, isPositive: boolean }) => (
  <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/30 border border-slate-800 hover:border-blue-500/30 transition-all group cursor-pointer">
    <div className="flex items-center gap-3">
      <div className="size-8 rounded-lg bg-slate-800 flex items-center justify-center text-[10px] font-bold text-white">
        {symbol.substring(0, 2)}
      </div>
      <div>
        <p className="text-xs font-bold text-white">{symbol}</p>
        <p className="text-[10px] text-slate-500 font-medium">Index Fund</p>
      </div>
    </div>
    <div className="text-right">
      <p className="text-xs font-bold text-white">{price}</p>
      <p className={`text-[10px] font-bold ${isPositive ? 'text-emerald-500' : 'text-rose-500'}`}>
        {isPositive ? '+' : ''}{change}
      </p>
    </div>
  </div>
);

const RiskAnalysisModal = ({ isOpen, onClose, theme }: { isOpen: boolean, onClose: () => void, theme: any }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-[#141b26] w-full max-w-2xl rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-800/20">
          <div className="flex items-center gap-3">
            <Shield className="text-rose-500" size={24} />
            <div>
              <h2 className="text-xl font-bold text-white">Full Risk Analysis</h2>
              <p className="text-xs text-slate-400">{theme.title}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all">
            <TrendingUp size={20} className="rotate-45" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-slate-800/30 border border-slate-800">
              <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Exposure</p>
              <p className="text-lg font-bold text-white">High</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-800/30 border border-slate-800">
              <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Velocity</p>
              <p className="text-lg font-bold text-rose-500">Accelerating</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-800/30 border border-slate-800">
              <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Confidence</p>
              <p className="text-lg font-bold text-emerald-500">84%</p>
            </div>
          </div>
          
          <section>
            <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Info size={16} className="text-blue-500" /> Strategic Implications
            </h3>
            <div className="space-y-4">
              {theme.riskImplications.map((risk: string, i: number) => (
                <div key={i} className="p-4 rounded-2xl bg-slate-800/20 border border-slate-800/50">
                  <p className="text-sm text-slate-300 leading-relaxed">{risk}</p>
                  <div className="mt-3 flex items-center gap-4 text-[10px] font-bold uppercase tracking-widest text-slate-500">
                    <span className="flex items-center gap-1"><AlertTriangle size={12} className="text-amber-500" /> Action Required</span>
                    <span className="flex items-center gap-1"><Clock size={12} /> T-Minus 48h</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-sm font-bold text-white mb-4">Recommended Mitigation</h3>
            <div className="p-5 rounded-2xl bg-blue-600/5 border border-blue-600/20">
              <p className="text-sm text-blue-100 leading-relaxed">
                Hedge exposure via long-dated put options on EMEA energy indices. Reallocate 15% of growth capital to defensive utilities and short-term liquidity instruments.
              </p>
            </div>
          </section>
        </div>
        <div className="p-6 border-t border-slate-800 bg-slate-800/10 flex gap-4">
          <button className="flex-1 py-3 rounded-xl bg-blue-600 text-white text-sm font-bold hover:bg-blue-500 transition-all">
            Generate Executive Report
          </button>
          <button onClick={onClose} className="px-6 py-3 rounded-xl border border-slate-700 text-sm font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-all">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

const AIMarketInsight = () => {
  const [insight, setInsight] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const generateInsight = async () => {
    setIsLoading(true);
    const response = await askMacroAgent("Provide a brief, high-level macro economic insight based on current global market conditions (March 2026). Focus on one key trend and its implication for institutional investors.");
    setInsight(response.text);
    setIsLoading(false);
  };

  React.useEffect(() => {
    generateInsight();
  }, []);

  return (
    <div className="bg-blue-600/5 border border-blue-500/20 rounded-2xl p-6 mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-blue-500">
          <Sparkles size={18} />
          <h2 className="text-sm font-bold uppercase tracking-widest">AI Market Intelligence</h2>
        </div>
        <button 
          onClick={generateInsight}
          disabled={isLoading}
          className="text-[10px] font-bold text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-1 uppercase tracking-widest"
        >
          {isLoading ? <Loader2 size={12} className="animate-spin" /> : <Activity size={12} />} Refresh Insight
        </button>
      </div>
      {isLoading ? (
        <div className="flex items-center gap-3 text-slate-500 text-sm">
          <Loader2 className="animate-spin" size={16} /> Synthesizing global market data...
        </div>
      ) : (
        <p className="text-sm text-slate-300 leading-relaxed">
          {insight || "Select refresh to generate a new market intelligence report."}
        </p>
      )}
    </div>
  );
};

const Dashboard = () => {
  const { themes } = useInstitutionalMemory();
  const [selectedTheme, setSelectedTheme] = useState<any>(null);
  const [isRiskModalOpen, setIsRiskModalOpen] = useState(false);
  const [tickerIndex, setTickerIndex] = useState(0);

  const riskFactors = [
    { name: 'Geopolitical Tension', level: 'High', description: 'Escalation in EMEA supply routes impacting energy costs.' },
    { name: 'Liquidity Stress', level: 'High', description: 'Secondary bond markets showing signs of reduced depth.' },
    { name: 'Inflation Volatility', level: 'Medium', description: 'Core services inflation remains sticky in US and EU.' },
    { name: 'Semiconductor Supply', level: 'High', description: 'Production contraction in APAC affecting tech manufacturing.' }
  ];

  const tickerNews = [
    "BLOOMBERG: Fed officials signal potential rate hike in March 2026 meeting...",
    "REUTERS: Global semiconductor output falls 25% in early March...",
    "FT: Germany activates emergency energy rationing for heavy industry...",
    "GOLDMAN SACHS: 2026 Global Growth forecast upgraded to 3.1%...",
    "CNBC: Brent Crude surges past $95 on EMEA supply concerns..."
  ];

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % tickerNews.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="px-6 md:px-8 space-y-8">
      <AIMarketInsight />
      {/* Real-time Ticker */}
      <div className="bg-blue-600/10 border-y border-blue-500/20 py-2 -mx-6 md:-mx-8 overflow-hidden">
        <div className="flex items-center gap-8 animate-marquee whitespace-nowrap">
          {tickerNews.map((news, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="size-1.5 rounded-full bg-blue-500" />
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">{news}</span>
            </div>
          ))}
          {/* Duplicate for seamless loop */}
          {tickerNews.map((news, i) => (
            <div key={`dup-${i}`} className="flex items-center gap-2">
              <span className="size-1.5 rounded-full bg-blue-500" />
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">{news}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Market Snapshot & Watchlist */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <section className="lg:col-span-3">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Market Snapshot</h2>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded uppercase">Real-time Data</span>
              <button className="text-xs font-bold text-blue-500 hover:underline">View All</button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <MarketCard title="S&P 500" value="5,137.08" change="+0.85%" isPositive={true} />
            <MarketCard title="NASDAQ" value="16,274.94" change="-0.12%" isPositive={false} />
            <MarketCard title="USD INDEX" value="103.42" change="+0.05%" isPositive={true} />
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Watchlist</h2>
            <button className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-400 hover:text-white transition-all">
              <Plus size={14} />
            </button>
          </div>
          <div className="bg-[#141b26] p-4 rounded-2xl border border-slate-800/50 space-y-3">
            <WatchlistCard symbol="VTI" price="254.12" change="1.24" isPositive={true} />
            <WatchlistCard symbol="QQQ" price="442.89" change="-0.45" isPositive={false} />
            <WatchlistCard symbol="AGG" price="98.45" change="0.12" isPositive={true} />
          </div>
        </section>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Risk Radar & Themes */}
        <div className="lg:col-span-2 space-y-8">
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">AI Macro Risk Radar</h2>
              <span className="text-[10px] font-bold text-rose-500 bg-rose-500/10 px-2 py-1 rounded uppercase">High Alert</span>
            </div>
            <div 
              onClick={() => setIsRiskModalOpen(true)}
              className="bg-[#141b26] p-6 rounded-2xl border border-slate-800/50 flex flex-col md:flex-row gap-8 cursor-pointer hover:border-blue-500/30 transition-all group"
            >
              <div className="relative size-48 mx-auto md:mx-0 flex items-center justify-center">
                <div className="absolute inset-0 border border-dashed border-slate-800 rounded-full group-hover:border-blue-500/30 transition-colors"></div>
                <div className="absolute inset-[20%] border border-dashed border-slate-800 rounded-full"></div>
                <div className="absolute inset-[40%] border border-dashed border-slate-800 rounded-full"></div>
                <svg className="absolute inset-0 w-full h-full drop-shadow-lg" viewBox="0 0 100 100">
                  <polygon 
                    points="50,10 85,35 75,80 50,95 20,70 15,30" 
                    className="fill-blue-500/20 stroke-blue-500 stroke-2"
                  />
                  <circle cx="50" cy="10" r="2" className="fill-rose-500" />
                  <circle cx="85" cy="35" r="2" className="fill-rose-500" />
                </svg>
                <div className="text-center z-10">
                  <p className="text-2xl font-bold text-white">7.8</p>
                  <p className="text-[10px] font-bold text-slate-500 uppercase">Risk Index</p>
                </div>
              </div>
              <div className="flex-1 space-y-4">
                <h3 className="text-lg font-bold text-white group-hover:text-blue-400 transition-colors">Volatility Spike Detected</h3>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Geopolitical tensions impacting energy sectors across EMEA markets. Neural models detect convergence of Liquidity Stress and Geopolitical Escalation.
                </p>
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="p-3 bg-slate-800/30 rounded-xl border border-slate-800">
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Peak Risk</p>
                    <p className="text-sm font-bold text-white">Liquidity</p>
                  </div>
                  <div className="p-3 bg-slate-800/30 rounded-xl border border-slate-800">
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Momentum</p>
                    <p className="text-sm font-bold text-rose-500">+18.4%</p>
                  </div>
                </div>
                <p className="text-[10px] text-blue-500 font-bold uppercase tracking-widest flex items-center gap-1">
                  <Info size={12} /> Click to view risk factors
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Trending Macro Themes</h2>
              <button className="text-xs font-bold text-blue-500 hover:underline">Explore All</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {themes.map(theme => (
                <div key={theme.id} className="bg-[#141b26] p-6 rounded-2xl border border-slate-800/50 hover:border-blue-500/30 transition-all group">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-bold text-white group-hover:text-blue-400 transition-colors">{theme.title}</h3>
                      {theme.status === 'hot' ? <Flame size={16} className="text-rose-500 animate-pulse" /> : theme.status === 'cold' ? <Snowflake size={16} className="text-blue-400" /> : null}
                    </div>
                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${
                      theme.status === 'hot' ? 'bg-rose-500/10 text-rose-500' : theme.status === 'cold' ? 'bg-blue-500/10 text-blue-400' : 'bg-slate-500/10 text-slate-400'
                    }`}>
                      {theme.status}
                    </span>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-rose-500 mb-2">
                      <Shield size={14} />
                      <span className="text-[10px] font-bold uppercase tracking-widest">Risk Implications</span>
                    </div>
                    {theme.riskImplications.slice(0, 2).map((risk, i) => (
                      <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-slate-800/30 border border-slate-800/50">
                        <div className="size-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                        <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">{risk}</p>
                      </div>
                    ))}
                  </div>
                  <button 
                    onClick={() => setSelectedTheme(theme)}
                    className="w-full mt-6 py-3 rounded-xl bg-slate-800/50 border border-slate-700 text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
                  >
                    View Full Risk Analysis <ArrowRight size={14} />
                  </button>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Calendar & Sentiment */}
        <div className="space-y-8">
          <section>
            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-4">Macro Event Timeline</h2>
            <div className="bg-[#141b26] rounded-2xl border border-slate-800/50 overflow-hidden">
              <div className="p-4 border-b border-slate-800 bg-slate-800/20 flex items-center gap-3">
                <Calendar size={16} className="text-blue-500" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">Economic Calendar</span>
              </div>
              <div className="divide-y divide-slate-800">
                {[
                  { day: 'Wed', date: '20', event: 'FOMC Rate Decision', time: '14:00 EST', impact: 'High' },
                  { day: 'Thu', date: '21', event: 'Initial Jobless Claims', time: '08:30 EST', impact: 'Medium' },
                  { day: 'Fri', date: '22', event: 'Core PCE Price Index', time: '08:30 EST', impact: 'High' },
                ].map((item, i) => (
                  <div key={i} className="p-4 flex items-center gap-4 hover:bg-slate-800/30 transition-colors cursor-pointer">
                    <div className="flex flex-col items-center justify-center min-w-[48px] py-1 bg-slate-800/50 rounded-lg border border-slate-700">
                      <span className="text-[10px] font-bold text-slate-500 uppercase">{item.day}</span>
                      <span className="text-lg font-bold text-blue-500">{item.date}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-bold text-white truncate">{item.event}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] font-bold text-slate-500">{item.time}</span>
                        <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${item.impact === 'High' ? 'bg-rose-500/10 text-rose-500' : 'bg-amber-500/10 text-amber-500'}`}>
                          {item.impact}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full p-3 text-xs font-bold text-slate-500 hover:text-white transition-colors border-t border-slate-800">
                View Full Calendar
              </button>
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Sentiment Trend</h2>
              <div className="flex items-center gap-2">
                <div className="size-2 rounded-full bg-blue-500" />
                <span className="text-[10px] font-bold text-slate-500 uppercase">Actual</span>
                <div className="size-2 rounded-full bg-blue-500/30" />
                <span className="text-[10px] font-bold text-slate-500 uppercase">Predicted</span>
              </div>
            </div>
            <div className="bg-[#141b26] p-5 rounded-2xl border border-slate-800/50">
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-bold text-white">Institutional Sentiment Index</span>
                <span className="text-xs font-bold text-emerald-500 flex items-center gap-1">
                  <TrendingUp size={12} /> +12% Bullish
                </span>
              </div>
              <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={sentimentData}>
                    <defs>
                      <linearGradient id="colorSentiment" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis 
                      dataKey="name" 
                      stroke="#64748b" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false} 
                    />
                    <YAxis 
                      stroke="#64748b" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false} 
                      domain={[0, 100]}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', fontSize: '10px' }}
                      itemStyle={{ color: '#fff' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="prediction" 
                      stroke="#3b82f6" 
                      strokeDasharray="5 5"
                      fillOpacity={1} 
                      fill="url(#colorSentiment)" 
                    />
                    <Area 
                      type="monotone" 
                      dataKey="sentiment" 
                      stroke="#3b82f6" 
                      strokeWidth={3}
                      fillOpacity={0} 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <p className="mt-4 text-[10px] text-slate-500 leading-relaxed text-center italic">
                * Predictive model based on current liquidity trends and central bank rhetoric.
              </p>
            </div>
          </section>
        </div>
      </div>

      <RiskAnalysisModal 
        isOpen={!!selectedTheme} 
        onClose={() => setSelectedTheme(null)} 
        theme={selectedTheme} 
      />

      <RiskFactorsModal 
        isOpen={isRiskModalOpen}
        onClose={() => setIsRiskModalOpen(false)}
        factors={riskFactors}
      />
    </div>
  );
};

const MarketCard = ({ title, value, change, isPositive }: { title: string, value: string, change: string, isPositive: boolean }) => (
  <div className="bg-[#141b26] p-5 rounded-2xl shadow-sm border border-slate-800/50 hover:border-blue-500/30 transition-all group">
    <div className="flex justify-between items-start mb-4">
      <div>
        <h3 className="font-bold text-slate-400 text-sm uppercase tracking-wider">{title}</h3>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-2xl font-bold tracking-tight text-white">{value}</span>
          <span className={`text-sm font-bold flex items-center ${isPositive ? 'text-emerald-500' : 'text-rose-500'}`}>
            {isPositive ? <TrendingUp size={14} className="mr-1" /> : <TrendingDown size={14} className="mr-1" />}
            {change}
          </span>
        </div>
      </div>
      <div className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">USD • LIVE</div>
    </div>
    <div className="h-16 w-full opacity-50 group-hover:opacity-100 transition-opacity">
      <svg className="w-full h-full" viewBox="0 0 400 100" preserveAspectRatio="none">
        <path 
          d={isPositive ? "M0 80 Q 40 70, 80 85 T 160 60 T 240 75 T 320 40 T 400 20" : "M0 20 Q 40 30, 80 25 T 160 45 T 240 40 T 320 60 T 400 70"} 
          fill="none" 
          stroke={isPositive ? "#10b981" : "#f43f5e"} 
          strokeWidth="3" 
          strokeLinecap="round"
        />
      </svg>
    </div>
  </div>
);

export default Dashboard;
