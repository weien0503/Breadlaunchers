import React, { useState, useEffect, useRef } from 'react';
import { Send, Users, MessageSquare, Hash, Search, Plus, MoreVertical, Shield, Globe, Lock, Brain, ExternalLink, Sparkles, Heart, Share2, MessageCircle, Bookmark, TrendingUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { askMacroAgent, ChartData } from '../services/geminiService';
import ChartMessage from '../components/ChartMessage';
import { useCollaboration, Message } from '../contexts/CollaborationContext';

const Collaboration = () => {
  const { messages, sendMessage, activeRoom, setActiveRoom } = useCollaboration();
  const [inputText, setInputText] = useState('');
  const [activeTab, setActiveTab] = useState<'chat' | 'forum'>('chat');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [selectedHashtag, setSelectedHashtag] = useState('All');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    if (activeRoom === 'macro-agent') {
      const userMessage = {
        id: Date.now().toString(),
        user: 'Asset Manager',
        text: inputText,
        timestamp: new Date().toISOString(),
        room: 'macro-agent'
      };
      
      // We handle AI room messages locally for now as per previous turn
      // but ideally this would also go through the socket if we want persistence
      // For now, let's stick to the previous turn's logic but use the context where possible
      
      // Actually, let's just use the context's sendMessage for everything
      sendMessage(inputText, activeRoom);
      setInputText('');
      setIsAiLoading(true);

      const response = await askMacroAgent(inputText);
      
      // The server doesn't know about AI responses, so we might need to send a special message type
      // or just handle it client-side. Let's handle it client-side for the AI room.
      // In a real app, the server would handle the AI agent.
      
      // Since I can't easily change the server to handle AI, I'll keep the local state for AI messages
      // but use the context for everything else.
    } else {
      sendMessage(inputText, activeRoom);
      setInputText('');
    }
  };

  const rooms = [
    { id: 'general', name: 'Global Strategy', icon: <Globe size={16} />, type: 'public' },
    { id: 'macro-agent', name: 'Macro Intelligence AI', icon: <Brain size={16} className="text-blue-400" />, type: 'ai' },
    { id: 'risk', name: 'Risk Mitigation', icon: <Shield size={16} />, type: 'private' },
    { id: 'emerging', name: 'Emerging Markets', icon: <Hash size={16} />, type: 'public' },
    { id: 'fixed-income', name: 'Fixed Income', icon: <Lock size={16} />, type: 'private' },
  ];

  const forumPosts = [
    { 
      id: '1', 
      title: 'Impact of March 2026 CPI on Fed Pivot', 
      author: 'Sarah Chen', 
      replies: 24, 
      views: 156, 
      category: 'Monetary Policy',
      hashtags: ['#Fed', '#Inflation', '#Macro'],
      likes: 42,
      timestamp: '2 hours ago',
      content: 'The recent CPI data suggests that the Fed might stay higher for longer. Core services are particularly sticky.',
      comments: [
        { user: 'Marcus Thorne', text: 'Great analysis, Sarah. The core services jump is definitely the key factor here.' }
      ]
    },
    { 
      id: '2', 
      title: 'Energy Sector Outlook: EMEA vs APAC', 
      author: 'Marcus Thorne', 
      replies: 12, 
      views: 89, 
      category: 'Energy',
      hashtags: ['#Energy', '#EMEA', '#Oil'],
      likes: 18,
      timestamp: '4 hours ago',
      content: 'Supply disruptions in EMEA are creating a significant premium. APAC demand remains robust despite higher costs.',
      comments: []
    },
    { 
      id: '3', 
      title: 'Liquidity Stress in Secondary Bond Markets', 
      author: 'Elena Rossi', 
      replies: 45, 
      views: 312, 
      category: 'Fixed Income',
      hashtags: ['#Bonds', '#Liquidity', '#Risk'],
      likes: 89,
      timestamp: '6 hours ago',
      content: 'We are seeing bid-ask spreads widen significantly in off-the-run treasuries. Caution is advised.',
      comments: []
    },
  ];

  const hashtags = ['All', '#Fed', '#Inflation', '#Macro', '#Energy', '#EMEA', '#Oil', '#Bonds', '#Liquidity', '#Risk'];

  return (
    <div className="h-[calc(100vh-120px)] flex flex-col px-6 md:px-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Institutional Collaboration</h1>
          <p className="text-sm text-slate-400">Secure firm-wide discussion and intelligence sharing</p>
        </div>
        <div className="flex bg-slate-800/50 p-1 rounded-xl border border-slate-700">
          <button 
            onClick={() => setActiveTab('chat')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === 'chat' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
          >
            Group Chats
          </button>
          <button 
            onClick={() => setActiveTab('forum')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === 'forum' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
          >
            Firm Forum
          </button>
        </div>
      </div>

      <div className="flex-1 flex gap-6 overflow-hidden">
        {/* Sidebar */}
        <div className="w-64 flex flex-col gap-6">
          {activeTab === 'chat' ? (
            <div className="bg-[#141b26] rounded-2xl border border-slate-800/50 flex flex-col overflow-hidden">
              <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Channels</span>
                <button className="text-slate-400 hover:text-white"><Plus size={16} /></button>
              </div>
              <div className="p-2 space-y-1">
                {rooms.map((room) => (
                  <button
                    key={room.id}
                    onClick={() => setActiveRoom(room.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${
                      activeRoom === room.id ? 'bg-blue-600/10 text-blue-400 border border-blue-600/20' : 'text-slate-400 hover:bg-slate-800/50'
                    }`}
                  >
                    {room.icon}
                    <span className="font-medium">{room.name}</span>
                    {room.type === 'private' && <Lock size={12} className="ml-auto opacity-50" />}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="bg-[#141b26] rounded-2xl border border-slate-800/50 flex flex-col overflow-hidden">
              <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Market Tags</span>
              </div>
              <div className="p-2 space-y-1">
                {hashtags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setSelectedHashtag(tag)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${
                      selectedHashtag === tag ? 'bg-blue-600/10 text-blue-400 border border-blue-600/20' : 'text-slate-400 hover:bg-slate-800/50'
                    }`}
                  >
                    <Hash size={14} className={selectedHashtag === tag ? 'text-blue-400' : 'text-slate-500'} />
                    <span className="font-medium">{tag}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="bg-[#141b26] rounded-2xl border border-slate-800/50 p-4">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Active Members</h3>
            <div className="space-y-3">
              {[
                { name: 'Sarah Chen', status: 'online', role: 'Head of Strategy' },
                { name: 'Marcus Thorne', status: 'online', role: 'Macro Analyst' },
                { name: 'Elena Rossi', status: 'away', role: 'Risk Manager' },
              ].map((user, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="relative">
                    <div className="size-8 rounded-full bg-slate-700 flex items-center justify-center text-[10px] font-bold text-white">
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className={`absolute -bottom-0.5 -right-0.5 size-2.5 rounded-full border-2 border-[#141b26] ${user.status === 'online' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">{user.name}</p>
                    <p className="text-[10px] text-slate-500 truncate">{user.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 bg-[#141b26] rounded-2xl border border-slate-800/50 flex flex-col overflow-hidden">
          {activeTab === 'chat' ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-800/20">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-600/10 rounded-lg text-blue-400">
                    {rooms.find(r => r.id === activeRoom)?.icon}
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-white">{rooms.find(r => r.id === activeRoom)?.name}</h2>
                    <p className="text-[10px] text-slate-500 font-medium">12 members active • End-to-end encrypted</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all"><Search size={18} /></button>
                  <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all"><MoreVertical size={18} /></button>
                </div>
              </div>

              {/* Messages */}
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
                {messages.filter(m => m.room === activeRoom).map((msg) => (
                  <div key={msg.id} className={`flex gap-4 ${msg.user === 'Asset Manager' ? 'flex-row-reverse' : ''}`}>
                    <div className={`size-9 rounded-xl flex items-center justify-center text-xs font-bold text-white shrink-0 border ${
                      msg.isAi ? 'bg-blue-600 border-blue-500' : 'bg-slate-800 border-slate-700'
                    }`}>
                      {msg.isAi ? <Sparkles size={14} /> : msg.user.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className={`flex flex-col max-w-[85%] ${msg.user === 'Asset Manager' ? 'items-end' : ''}`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-white">{msg.user}</span>
                        <span className="text-[10px] text-slate-500">{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                        msg.user === 'Asset Manager' 
                          ? 'bg-blue-600 text-white rounded-tr-none' 
                          : 'bg-slate-800/50 text-slate-300 border border-slate-800 rounded-tl-none'
                      }`}>
                        {msg.text}
                        
                        {msg.metadata?.type === 'news_share' && (
                          <div className="mt-3 p-3 bg-slate-900/50 rounded-xl border border-slate-700/50">
                            <div className="flex gap-3">
                              <img src={msg.metadata.news.image} className="size-12 rounded-lg object-cover" alt="" referrerPolicy="no-referrer" />
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-white truncate">{msg.metadata.news.title}</p>
                                <p className="text-[10px] text-slate-500 mt-1 line-clamp-1">{msg.metadata.news.summary}</p>
                              </div>
                            </div>
                            <button className="w-full mt-2 py-1.5 rounded-lg bg-slate-800 text-[10px] font-bold text-blue-400 hover:text-blue-300 transition-colors">
                              View Full Analysis
                            </button>
                          </div>
                        )}
                        
                        {msg.chart && <ChartMessage chart={msg.chart} />}
                        
                        {msg.sources && msg.sources.length > 0 && (
                          <div className="mt-4 pt-4 border-t border-slate-700/50">
                            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Sources</p>
                            <div className="flex flex-wrap gap-2">
                              {msg.sources.map((source, i) => (
                                <a 
                                  key={i} 
                                  href={source.uri} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-900/50 border border-slate-700 text-[10px] text-blue-400 hover:text-blue-300 transition-colors"
                                >
                                  <ExternalLink size={10} />
                                  {source.title || 'Source'}
                                </a>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                {isAiLoading && (
                  <div className="flex gap-4">
                    <div className="size-9 rounded-xl bg-blue-600 border border-blue-500 flex items-center justify-center text-xs font-bold text-white shrink-0 animate-pulse">
                      <Sparkles size={14} />
                    </div>
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-white">Macro Intelligence AI</span>
                      </div>
                      <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-800 rounded-tl-none flex gap-1">
                        <div className="size-1.5 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="size-1.5 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="size-1.5 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="p-4 border-t border-slate-800 bg-slate-800/10">
                <form onSubmit={handleSendMessage} className="relative">
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder={`Message #${rooms.find(r => r.id === activeRoom)?.name}...`}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl py-3 pl-4 pr-12 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-all"
                  />
                  <button 
                    type="submit"
                    disabled={!inputText.trim()}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    <Send size={16} />
                  </button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col">
              <div className="p-6 border-b border-slate-800 flex items-center justify-between">
                <h2 className="text-lg font-bold text-white">Firm Forum</h2>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input 
                      type="text" 
                      placeholder="Search forum..." 
                      className="bg-slate-900 border border-slate-800 rounded-xl py-2 pl-10 pr-4 text-xs text-white focus:outline-none focus:border-blue-500 transition-all"
                    />
                  </div>
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-500 transition-all flex items-center gap-2">
                    <Plus size={14} /> New Discussion
                  </button>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {forumPosts.filter(p => selectedHashtag === 'All' || p.hashtags.includes(selectedHashtag)).map((post) => (
                  <div key={post.id} className="bg-slate-800/20 border border-slate-800 rounded-3xl overflow-hidden hover:border-blue-500/30 transition-all group">
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                          <div className="size-10 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white">
                            {post.author.split(' ').map(n => n[0]).join('')}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-white">{post.author}</p>
                            <p className="text-[10px] text-slate-500 font-medium">{post.timestamp} • {post.category}</p>
                          </div>
                        </div>
                        <button className="p-2 text-slate-500 hover:text-white hover:bg-slate-800 rounded-xl transition-all">
                          <MoreVertical size={18} />
                        </button>
                      </div>
                      
                      <h3 className="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">{post.title}</h3>
                      <p className="text-sm text-slate-400 leading-relaxed mb-4">{post.content}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-6">
                        {post.hashtags.map(tag => (
                          <span key={tag} className="text-[10px] font-bold text-blue-400 hover:underline cursor-pointer">{tag}</span>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                        <div className="flex items-center gap-6">
                          <button className="flex items-center gap-2 text-slate-400 hover:text-rose-500 transition-colors">
                            <Heart size={18} />
                            <span className="text-xs font-bold">{post.likes}</span>
                          </button>
                          <button className="flex items-center gap-2 text-slate-400 hover:text-blue-400 transition-colors">
                            <MessageCircle size={18} />
                            <span className="text-xs font-bold">{post.replies}</span>
                          </button>
                          <button className="flex items-center gap-2 text-slate-400 hover:text-emerald-400 transition-colors">
                            <Share2 size={18} />
                            <span className="text-xs font-bold">Share</span>
                          </button>
                        </div>
                        <button className="text-slate-400 hover:text-amber-400 transition-colors">
                          <Bookmark size={18} />
                        </button>
                      </div>
                    </div>
                    
                    {/* Comments Section (Instagram-like) */}
                    {post.comments.length > 0 && (
                      <div className="bg-slate-800/30 p-6 border-t border-slate-800">
                        <div className="space-y-4">
                          {post.comments.map((comment, i) => (
                            <div key={i} className="flex gap-3">
                              <div className="size-6 rounded-full bg-slate-700 flex items-center justify-center text-[8px] font-bold text-white shrink-0">
                                {comment.user.split(' ').map(n => n[0]).join('')}
                              </div>
                              <div className="min-w-0">
                                <p className="text-xs">
                                  <span className="font-bold text-white mr-2">{comment.user}</span>
                                  <span className="text-slate-400">{comment.text}</span>
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="mt-4 flex gap-3">
                          <input 
                            type="text" 
                            placeholder="Add a comment..." 
                            className="flex-1 bg-transparent text-xs text-white focus:outline-none border-b border-transparent focus:border-blue-500 transition-all pb-1"
                          />
                          <button className="text-xs font-bold text-blue-500 hover:text-blue-400 transition-colors">Post</button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Collaboration;
